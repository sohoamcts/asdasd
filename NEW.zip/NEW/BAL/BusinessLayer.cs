﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using DAL;
using CO;

namespace BAL
{
    public class BusinessLayer
    {
        DataAccess da = new DataAccess();

        public int Sid { get; set; }
        public string Sname { get; set; }
        public string Smarks { get; set; }
        public int standard { get; set; }


        //Rooms Variables

        
        public int Rid { get; set; }
        public string hotelname { get; set; }
        public int city { get; set; }
        public string descriptn { get; set; }
        public int noofACs { get; set; }
        public int rentofAC { get; set; }
        public int rentofnonAC { get; set; }
        public int noofrooms { get; set; }
        public string bookedfrom { get; set; }
        public string bookedto { get; set; }
        public int adultcap { get; set; }
        public int childrencap { get; set; }

        SqlCommand cmd = new SqlCommand();

        public DataSet BL_bind()
        {
            return da.AL_Bind();
        }

        //public void insert_data()
        //{
        //    cmd.Parameters.AddWithValue("@sid", Sid);
        //    cmd.Parameters.AddWithValue("@sname",Sname);
        //    cmd.Parameters.AddWithValue("@smarks", Smarks);
        //    cmd.Parameters.AddWithValue("@std", standard);
        //    da.insert_sp(cmd); 
        //}

        public void insert_room()
        {
            cmd.Parameters.AddWithValue("@rid",Rid);
            cmd.Parameters.AddWithValue("@hotelname",hotelname);
            cmd.Parameters.AddWithValue("@cityid",city);
            cmd.Parameters.AddWithValue("@desc", descriptn);
            cmd.Parameters.AddWithValue("@noofac",noofACs);
            cmd.Parameters.AddWithValue("@rentofAC",rentofAC);
            cmd.Parameters.AddWithValue("@rentofnonAC", rentofnonAC);
            cmd.Parameters.AddWithValue("@noofrooms", noofrooms);
            cmd.Parameters.AddWithValue("@bookedfrom", bookedfrom);
            cmd.Parameters.AddWithValue("@bookedto", bookedto);
            cmd.Parameters.AddWithValue("@adltcap", adultcap);
            cmd.Parameters.AddWithValue("@childrencap", childrencap);
            da.insert_room_sp(cmd);

        }

        //public void update_data(int Sid)
        //{
        //    cmd.Parameters.AddWithValue("@sid",Sid);
        //    cmd.Parameters.AddWithValue("@sname", Sname);
        //    cmd.Parameters.AddWithValue("@smarks", Smarks);
        //    cmd.Parameters.AddWithValue("@std", standard);
        //    da.update_sp(cmd);
        //}

        //public void delete_data(int Sid)
        //{
        //    cmd.Parameters.AddWithValue("@sid",Sid);
        //    da.delete_sp(cmd);
        //}
    }
}
