﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace DAL
{
    public class DataAccess
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["newdb"].ConnectionString);

        public DataSet AL_Bind()
        {
            SqlDataAdapter sda = new SqlDataAdapter("select_sp", con);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            return ds;
        }

        public void insert_room_sp(SqlCommand cmd)
        {
            con.Open();
            cmd.Connection = con;
            cmd.CommandText = "insert_room_sp";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();
        }

        //public void update_sp(SqlCommand cmd)
        //{
        //    con.Open();
        //    cmd.Connection = con;
        //    cmd.CommandText = "update_sp";
        //    cmd.CommandType = CommandType.StoredProcedure;
        //    cmd.ExecuteNonQuery();
        //}

        //public void delete_sp(SqlCommand cmd)
        //{
        //    con.Open();
        //    cmd.Connection = con;
        //    cmd.CommandText = "delete_sp";
        //    cmd.CommandType = CommandType.StoredProcedure;
        //    cmd.ExecuteNonQuery();
        //}



    }
}
