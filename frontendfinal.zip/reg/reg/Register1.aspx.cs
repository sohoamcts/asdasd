﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace reg
{
    public partial class Register1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void btn1_Click(object sender, EventArgs e)
        {
            //if (msg == "success")
            //{
            //    btn1.Visible = false;
            //    Label1.Text = "Login Successful !! Now Login";

            //}
            //else
            //{
            //    Label1.Text = "Login Unsucessful... please try again !! ";
            //}
        }
    }
}